package com.blueteam.namuwikiviewer;

public class ItemObject {

    private String title;
    private String img_url;
    private String detail_link;
    private String score;
    private String date;
    private String comment;

    public ItemObject(String title, String url, String link, String score, String date, String comment){
        this.title = title;
        this.img_url = url;
        this.detail_link = link;
        this.score = score;
        this.date = date;
        this.comment = comment;
    }


    public String getTitle() {
        return title;
    }

    public String getImg_url() {
        return img_url;
    }

    public String getDetail_link() {
        return detail_link;
    }

    public String getScore(){
        return score;
    }

    public String getDate() {
        return date;
    }

    public String getComment() {
        return comment;
    }
}
